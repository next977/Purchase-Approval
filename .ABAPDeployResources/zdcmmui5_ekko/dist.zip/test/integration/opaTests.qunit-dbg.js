/* global QUnit */

sap.ui.require(["SYNC/zdcmmui5ekko/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
