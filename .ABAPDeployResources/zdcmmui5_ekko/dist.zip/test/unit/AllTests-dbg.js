sap.ui.define([
	"SYNC/zdcmmui5_ekko/test/unit/controller/app.controller"
], function () {
	"use strict";
});
